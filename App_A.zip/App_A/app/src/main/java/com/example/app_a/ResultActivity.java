package com.example.app_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.function.ToIntFunction;

public class ResultActivity extends AppCompatActivity {

    TextView txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        txt2 = (TextView) findViewById(R.id.textView2);
        Intent intent = getIntent();
        String st = intent.getStringExtra("EXTRA_MESSAGE");

        int s = Integer.parseInt(st);


        for(int i = 0;i<s;i++){
            txt2.append(" "+st);
        }
    }
}
