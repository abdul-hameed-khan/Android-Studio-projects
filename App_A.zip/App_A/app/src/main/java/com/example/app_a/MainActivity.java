// Abdul Hameed Khan FA18-BCS-002

package com.example.app_a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btn1;
    Button btn2;
    TextView txt1;
    Random n = new Random();
    int num = n.nextInt(20)+1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        btn1 = (Button) findViewById(R.id.button);
//        btn2 = (Button) findViewById(R.id.button2);


    }
    public void send_msg(View view) {
        Intent intent = new Intent(getApplicationContext(),ResultActivity.class);
        txt1 =  (TextView) findViewById(R.id.textView);
        String message = txt1.getText().toString();
        intent.putExtra("EXTRA_MESSAGE", message);
        startActivity(intent);


    }
    public void msg(View view) {
        txt1 =  (TextView) findViewById(R.id.textView);
        txt1.setText(Integer.toString(num));


    }
}