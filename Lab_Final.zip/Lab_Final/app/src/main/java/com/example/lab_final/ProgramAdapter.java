package com.example.lab_final;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Toast;


public class ProgramAdapter extends ArrayAdapter<String> {
    Context context;
    int[] images;
    String[] bookname;
    String[] price;
    public ProgramAdapter(Context context, String[] bookname,String[] price,int[] image) {
        super(context,R.layout.single_item,R.id.textView,bookname);
        this.context=context;
        this.images=image;
        this.bookname=bookname;
        this.price=price;
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {   View singleItem=convertView;
        ProgramViewHolder holder=null;
        if (singleItem==null)
        {
            LayoutInflater li = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            singleItem=li.inflate(R.layout.single_item,parent,false);
            holder= new ProgramViewHolder(singleItem);
            singleItem.setTag(holder);
        }
        else
        {
            holder=(ProgramViewHolder) singleItem.getTag();
            holder.image.setImageResource(images[position]);
            holder.bookname.setText(bookname[position]);
            holder.price.setText(price[position]);
            singleItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getContext(), "You Clicked:"+bookname[position], Toast.LENGTH_SHORT).show();
                }
            });
        }
        return singleItem;
        //return super.getView(position,convertView,parent);
    }
}
