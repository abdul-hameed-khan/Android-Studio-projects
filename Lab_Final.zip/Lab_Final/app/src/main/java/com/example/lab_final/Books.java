package com.example.lab_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class Books extends AppCompatActivity {
    ListView listview1;
    String[] bookname={"Quran","Bukhari","Muslim"};
    String[] price={"1200","9500","5600"};
    int[] image={R.drawable.quran,R.drawable.bukhari,R.drawable.muslim};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);
        listview1=findViewById(R.id.listView1);
        ProgramAdapter pg = new ProgramAdapter(this,bookname,price,image);
        listview1.setAdapter(pg);
    }

}