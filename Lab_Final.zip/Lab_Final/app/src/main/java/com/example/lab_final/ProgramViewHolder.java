package com.example.lab_final;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class ProgramViewHolder {
    ImageView image;
    TextView bookname;
    TextView price;
    ProgramViewHolder(View view)
    {
        image=view.findViewById(R.id.imageView);
        bookname=view.findViewById(R.id.textView10);
        price=view.findViewById(R.id.textView9);

    }
}
