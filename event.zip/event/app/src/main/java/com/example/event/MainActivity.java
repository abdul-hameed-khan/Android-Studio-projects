package com.example.event;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
public class MainActivity extends AppCompatActivity {
    Button button1,button2;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//my code
        ConstraintLayout bgElement=(ConstraintLayout)
                findViewById(R.id.activity_main);
        bgElement.setBackgroundColor(Color.YELLOW);
        //way-2--following call is for button1, to call onClickListener using

        myButton1ListenerMethod();
// capture button2 id
        button2=(Button)findViewById(R.id.button2);

button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConstraintLayout bgElement=(ConstraintLayout)
                        findViewById(R.id.activity_main);
                int color=((ColorDrawable)bgElement.getBackground()).getColor();
                if(color==Color.MAGENTA)
                {bgElement.setBackgroundColor(Color.DKGRAY);}
                else
                {bgElement.setBackgroundColor(Color.MAGENTA);}
            }
        });//end setOnClickListener()
    }
    public void myButton1ListenerMethod()
    {
        button1=(Button)findViewById(R.id.button1);
//implementation of OnClickListener interface anonymously
//We implemented the listener object inline and as an anonymous class
        button1.setOnClickListener(new View.OnClickListener() {
            //onClick is an abstract method defined by the View.OnClickListener interface. It
// needs to be overridden for our implementation
            @Override
            public void onClick(View v) {
                ConstraintLayout bgElement=(ConstraintLayout)
                        findViewById(R.id.activity_main);
                int
                        color=((ColorDrawable)bgElement.getBackground()).getColor();
                if(color==Color.CYAN)
                {bgElement.setBackgroundColor(Color.BLUE);}
                else
                {bgElement.setBackgroundColor(Color.CYAN);}
            }
        });//end setOnClickListener()
    }//ends myButton1ListenerMethod
//way-1 the following method called in response of onClick property on

    public void change_text(View view)
    {
        textView=(TextView)findViewById(R.id.textView1);
        textView.setText("Welcome in Event Handling");
    }
}