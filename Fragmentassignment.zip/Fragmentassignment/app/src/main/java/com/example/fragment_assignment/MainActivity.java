package com.example.fragment_assignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentManager manager=getSupportFragmentManager();
        //step-2
        FragmentTransaction t1=manager.beginTransaction();
        //step-3
        MyFragment1 myFragment1=new MyFragment1();
        MyFragment2 myFragment2=new MyFragment2();
        //step-4
        t1.add(R.id.frame1,myFragment1);
        t1.add(R.id.frame2,myFragment2);
        //step-5
        t1.commit();
    }
    //my code
    public void towards_fragment2(String num)
    {
        //following 5 steps are needed to create connection between two fragments
        //step-1
        FragmentManager fm=getSupportFragmentManager();
        //step-2
        FragmentTransaction t2=fm.beginTransaction();
        //step-3
        MyFragment2 myFragment22=new MyFragment2();
        //step-4
        Bundle b1=new Bundle();
        b1.putString("num",num);

        myFragment22.setArguments(b1);
        t2.add(R.id.frame2,myFragment22);
        //step-5
        t2.commit();
    }
}
